<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'All Links'); ?>

    <section class="breadCrum shadow-sm">
        <div class="container">
            <h2><?php echo e(__('All Links')); ?></h2>
        </div>
    </section>


    <div class="container mb-5">

        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

        <?php if($errors->first('title')): ?>
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6">
                <div class="mt-4 alert alert-danger">
                    <b><?php echo e($errors->first('title')); ?></b>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="card mb-5">
            <div class="card-header">
                <div class="text-right">
                    <div class="d-flex justify-content-between">
                        <div class="allLink text-left">
                            <p><b>All Links</b>: <?php echo e(count($links)); ?></p>
                            <p class="mb-0"><b>Total Clicks</b>: <?php echo e($totalClick); ?></p>
                        </div>
                        <div class="allLink">
                            <button class="btn btn-success" data-toggle="modal" data-target="#addLink">Create Link</button>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Link</th>
                        <th>No. of Clicks</th>
                        <th>Created On</th>
                        <th>Options</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#<?php echo e($link->id); ?></td>
                        <td><?php echo e($baseUrl.'/'.$link->link_name); ?></td>
                        <td><?php echo e($link->clicks); ?></td>
                        <td><?php echo e(date('M d, Y', strtotime($link->created_at))); ?></td>
                        <td style="width: 200px">
                            <a href="<?php echo e(route('singleLink', $link->id)); ?>" title="Edit Link" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>
                            <a href="<?php echo e(route('viewLink', $link->link_name)); ?>" title="View Link" class="btn btn-success btn-sm" target="_blank"><i class="fa fa-eye"></i></a>
                            <button title="Share Link" onclick='shareLink("<?php echo e($link->link_name); ?>", "<?php echo e($link->title); ?>")' class="btn btn-info btn-sm" data-toggle="modal" data-target="#shareLink"><i class="fa fa-share-alt"></i></button>
                            <button title="Share Link" onclick='copyLink("<?php echo e($link->link_name); ?>", "<?php echo e($link->title); ?>")' class="btn btn-info btn-sm"><i class="fa fa-copy"></i></button>
                            <button onclick="deleteLink(<?php echo e($link->id); ?>)" title="Delete Link" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No Links Available</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>


        <div class="d-flex justify-content-center">
            <?php echo $links->links(); ?>

        </div>
    </div>



    <!-- The Link Modal -->
    <div class="modal fade" id="addLink">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                <h4 class="modal-title">Create Link</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">

                    <form method="post" action="<?php echo e(route('addLink')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="title">Link Title</label>
                            <input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Personalised your link e.g: john doe is here" required>
                        </div>

                        <div class="mt-5">
                            <p class="text-danger">Do you want to add any information. whenever a user visit your link, the information you added below will be display</p>
                        </div>

                        <div class="form-group">
                            <label for="linkImg">Upload Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="linkImg" name="image">
                                <label class="custom-file-label" for="linkImg">Choose file</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="mytextarea">Content</label>
                            <textarea name="content" class="form-control" id="mytextarea" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
                        </div>

                        <div class="mt-4 text-center">
                            <button class="btn btn-primary">ADD LINK</button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    
    <div class="modal fade" id="shareLink">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                <h4 class="modal-title">Share Link</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">

                    <div class="d-flex justify-content-center">
                        <div class="share mr-3" id="facebookLink"></div>
                        <div class="share mr-3" id="twitterLink"></div>
                        <div class="share mr-3" id="linkedinLink"></div>
                        <div class="share mr-3" id="whatsappLink"></div>
                    </div>

                </div>

            </div>
        </div>
    </div>


    
    <div class="modal fade" id="deleteLinkModal">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <!-- Modal body -->
                <div class="modal-body">

                    <p class="text-center mb-4 mt-4">Are you sure you want to delete this link?</p>

                    <form action="<?php echo e(route("deleteLink")); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="deleteID" name="id">

                        <div class="text-center mb-3">
                            <button class="btn btn-danger btn-sm mr-5" type="submit">YES</button>
                            <button class="btn btn-success btn-sm ml-5" data-dismiss="modal" type="button">NO</button>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>


    <script>
        function shareLink(link, title) {
            document.getElementById('facebookLink').innerHTML = '<a href="https://www.facebook.com/share.php?u=<?php echo e($baseUrl); ?>/' + link + '" target="_blank" class="facebook"><span class="fa fa-facebook"></span></a>';
            document.getElementById('whatsappLink').innerHTML = '<a href="https://web.whatsapp.com/send?text=<?php echo e($baseUrl); ?>/' + link + '" target="_blank" class="whatsapp"><span class="fa fa-whatsapp"></span></a>';
            document.getElementById('twitterLink').innerHTML = '<a href="https://twitter.com/intent/tweet?text=' + title +'title&url=<?php echo e($baseUrl); ?>/' + link + '" target="_blank" class="twitter"><span class="fa fa-twitter"></span></a>';
            document.getElementById('linkedinLink').innerHTML = '<a href="https://www.linkedin.com/shareArticle?title=' + title + '&url=<?php echo e($baseUrl); ?>/' + link + '" target="_blank" class="linkedin"><span class="fa fa-linkedin"></span></a>';
        }

        function deleteLink(linkID) {
            $('#deleteLinkModal').modal();
            document.getElementById('deleteID').value = linkID;
        }

        function copyLink(link) {
            navigator.clipboard.writeText("<?php echo e($baseUrl); ?>/" + link);
            alert("Link successfully copied");
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\starkLogic\resources\views/links/list.blade.php ENDPATH**/ ?>