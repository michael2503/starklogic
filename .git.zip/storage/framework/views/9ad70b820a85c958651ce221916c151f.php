<header>

    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('assets/images/logoBWy.png')); ?>" alt="stark-Logic Logo" width="120">
        </a>

        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <?php if(Auth::user()): ?>
                <li class="nav-item">
                    <a class="nav-link <?php if(request()->routeIs('dashboard')): ?> isActive <?php endif; ?>" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(request()->routeIs('getLinks')): ?> isActive <?php endif; ?>" href="<?php echo e(route('getLinks')); ?>">Links</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(request()->routeIs('profile.edit')): ?> isActive <?php endif; ?>" href="<?php echo e(route('profile.edit')); ?>">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="event.preventDefault();
                    document.getElementById('logoutForm').submit();" href="#">Logout</a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">LOGIN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>">REGISTER</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <form method="POST" id="logoutForm" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
    </form>

</header>
<?php /**PATH C:\Laravel\starkLogic\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>