<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Register'); ?>

    <div class="form-bg">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8 col-md-8">

                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-6">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                    </div>



                    <form method="post" action="<?php echo e(route('register')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="text-center">
                            <img src="<?php echo e(asset('assets/images/logoBWy.png')); ?>" class="mb-3" width="170" alt="">
                            <div class="heading"><?php echo e(__('Welcome to Stark Logic, Please Sign Up')); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="form-group mt-4">
                                    <label for="name">Name</label>
                                    <input type="text" value="<?php echo e(old('name')); ?>" name="name" class="form-control" id="name">
                                    <div class="formErr"><?php echo e($errors->first('name')); ?></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group mt-4">
                                    <label for="email"><?php echo e(__('Email')); ?></label>
                                    <input type="email" value="<?php echo e(old('email')); ?>" name="email" class="form-control" id="email">
                                    <div class="formErr"><?php echo e($errors->first('email')); ?></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group mt-4">
                                    <label for="phone"><?php echo e(__('Phone')); ?></label>
                                    <input type="text" value="<?php echo e(old('phone')); ?>" name="phone" class="form-control" id="phone">
                                    <div class="formErr"><?php echo e($errors->first('phone')); ?></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group mt-4">
                                    <label for="password"><?php echo e(__('Password')); ?></label>
                                    <input type="password" class="form-control" name="password" id="password">
                                    <div class="formErr"><?php echo e($errors->first('password')); ?></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group mt-4">
                                    <label for="password_confirmation"><?php echo e(__('Confirm Password')); ?></label>
                                    <input type="password" class="form-control" name="password_confirmation" id="password_confirmation">
                                    <div class="formErr"><?php echo e($errors->first('password_confirmation')); ?></div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mt-4">
                            <button type="submit" class="btn btn-primary">
                                <span class="btn-txt"><?php echo e(__('SIGNUP')); ?></span>
                                <span class="btn-icon">
                                    <span class="fa fa-arrow-right"></span>
                                </span>
                            </button>
                        </div>

                        <div class="form-group text-center mt-5">
                            <p><?php echo e(__('Already a member?')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\starkLogic\resources\views/auth/register.blade.php ENDPATH**/ ?>