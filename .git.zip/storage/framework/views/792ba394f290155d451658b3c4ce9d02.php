<section>
    <header>
        <h5>
            <?php echo e(__('Update Password')); ?>

        </h5>

        <p>
            <small><?php echo e(__("Ensure your account is using a long, random password to stay secure.")); ?></small>
        </p>
    </header>

    <form method="post" action="<?php echo e(route('password.update')); ?>" class="mt-6 space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="form-group">
            <label for="current_password">Current Password</label>
            <input type="password" id="current_password" name="current_password" class="form-control" autocomplete="current-password" >
            <div class="formErr"><?php echo e($errors->updatePassword->first('current_password')); ?></div>
        </div>

        <div class="form-group">
            <label for="password_confirmation">New Password</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" autocomplete="new-password" >
            <div class="formErr"><?php echo e($errors->updatePassword->first('password_confirmation')); ?></div>
        </div>

        <div class="form-group">
            <label for="password_confirmation">New Password</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" autocomplete="new-password" >
            <div class="formErr"><?php echo e($errors->updatePassword->first('password_confirmation')); ?></div>
        </div>

        <div class="flex items-center gap-4">
            <button class="btn btn-primary">Save</button>
            
        </div>
    </form>
</section>
<?php /**PATH C:\Laravel\starkLogic\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>