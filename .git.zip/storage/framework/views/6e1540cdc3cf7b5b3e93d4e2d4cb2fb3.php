
<img src="<?php echo e(asset('assets/images/starlogic.jpg')); ?>" width="90" alt="">
<?php /**PATH C:\Laravel\starkLogic\resources\views/components/application-logo.blade.php ENDPATH**/ ?>