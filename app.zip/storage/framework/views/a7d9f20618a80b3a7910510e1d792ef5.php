<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title', 'Login'); ?>
    <!-- Session Status -->
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>


    <div class="form-bg">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 col-md-8">

                    <form method="post" action="<?php echo e(route('login')); ?>" class="form-horizontal">
                        <?php if(Session::get('failed')): ?>
                        <div class="mt-4 alert alert-danger">
                            <b><?php echo e(Session::get('failed')); ?></b>
                        </div>
                        <?php endif; ?>

                        <?php echo csrf_field(); ?>
                        <div class="text-center">
                            <img src="<?php echo e(asset('assets/images/starlogic.jpg')); ?>" class="mb-3" width="170" alt="">
                            <div class="heading"><?php echo e(__('Welcome to Stark Logic, Please Sign In')); ?></div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1"><?php echo e(__('Email')); ?></label>
                            <input type="email" value="<?php echo e(old('user')); ?>" name="email" class="form-control" id="exampleInputEmail1">
                            <div class="formErr"><?php echo e($errors->first('email')); ?></div>
                        </div>

                        <div class="form-group mt-4">
                            <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
                            <input type="password" class="form-control" name="password">
                            <div class="formErr"><?php echo e($errors->first('password')); ?></div>
                        </div>
                        

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <span class="btn-txt"><?php echo e(__('Login')); ?></span>
                                <span class="btn-icon">
                                    <span class="fa fa-arrow-right"></span>
                                </span>
                            </button>
                        </div>

                        <div class="form-group text-center mt-5">
                            <p><?php echo e(__('Not a member?')); ?> <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Laravel\starkLogic\resources\views/auth/login.blade.php ENDPATH**/ ?>