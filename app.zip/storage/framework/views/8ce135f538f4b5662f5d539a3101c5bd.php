<?php if(Session::get('failed')): ?>
<div class="row d-flex justify-content-center">
    <div class="col-lg-6">
        <div class="mt-4 alert alert-danger">
            <b><?php echo e(Session::get('failed')); ?></b>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\Laravel\starkLogic\resources\views/components/error-message.blade.php ENDPATH**/ ?>